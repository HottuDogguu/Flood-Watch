package com.example.floodwatch

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class DashboardActivity : AppCompatActivity() {

    private lateinit var waterLevelText: TextView
    private lateinit var rainfallText: TextView
    private lateinit var statusText: TextView
    private lateinit var lastUpdateText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Enable back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Dashboard"

        // Initialize views
        waterLevelText = findViewById(R.id.waterLevelText)
        rainfallText = findViewById(R.id.rainfallText)
        statusText = findViewById(R.id.statusText)
        lastUpdateText = findViewById(R.id.lastUpdateText)

        // Load dashboard data
        loadDashboardData()

        // Refresh button
        findViewById<CardView>(R.id.refreshCard).setOnClickListener {
            loadDashboardData()
            android.widget.Toast.makeText(this, "Data refreshed", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadDashboardData() {
        // Simulate loading data (in real app, this would come from API/sensors)
        val waterLevel = kotlin.random.Random.nextDouble(2.5, 4.5)
        val rainfall = kotlin.random.Random.nextDouble(0.0, 25.0)
        val status = when {
            waterLevel < 3.0 && rainfall < 10.0 -> "Normal"
            waterLevel < 4.0 && rainfall < 20.0 -> "Monitor"
            else -> "Alert"
        }

        // Update UI
        waterLevelText.text = String.format("%.2f m", waterLevel)
        rainfallText.text = String.format("%.1f mm", rainfall)
        statusText.text = status

        // Set status color
        val statusColor = when (status) {
            "Normal" -> android.graphics.Color.GREEN
            "Monitor" -> android.graphics.Color.parseColor("#FFA500")
            else -> android.graphics.Color.RED
        }
        statusText.setTextColor(statusColor)

        // Update timestamp
        val currentTime = java.text.SimpleDateFormat("MMM dd, yyyy HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date())
        lastUpdateText.text = "Last updated: $currentTime"
    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}