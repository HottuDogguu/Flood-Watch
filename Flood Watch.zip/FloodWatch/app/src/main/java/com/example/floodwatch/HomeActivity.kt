package com.example.floodwatch

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class HomeActivity : AppCompatActivity() {

    private lateinit var welcomeText: TextView
    private lateinit var dashboardCard: CardView
    private lateinit var announcementCard: CardView
    private lateinit var alertCard: CardView
    private lateinit var logoutCard: CardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Initialize views
        welcomeText = findViewById(R.id.welcomeText)
        dashboardCard = findViewById(R.id.dashboardCard)
        announcementCard = findViewById(R.id.announcementCard)
        alertCard = findViewById(R.id.alertCard)
        logoutCard = findViewById(R.id.logoutCard)

        // Get user email
        val prefs = getSharedPreferences("FloodWatchPrefs", MODE_PRIVATE)
        val userEmail = prefs.getString("userEmail", "User")
        welcomeText.text = "Welcome, ${userEmail?.substringBefore("@")}!"

        // Dashboard card click
        dashboardCard.setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        // Announcement card click
        announcementCard.setOnClickListener {
            startActivity(Intent(this, AnnouncementActivity::class.java))
        }

        // Alert card click
        alertCard.setOnClickListener {
            // Show current flood status
            val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            builder.setTitle("Flood Alert Status")
            builder.setMessage("Current Status: Normal\n\nNo active flood warnings in your area.")
            builder.setPositiveButton("OK", null)
            builder.show()
        }

        // Logout card click
        logoutCard.setOnClickListener {
            val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            builder.setTitle("Logout")
            builder.setMessage("Are you sure you want to logout?")
            builder.setPositiveButton("Yes") { _, _ ->
                prefs.edit().apply {
                    putBoolean("isLoggedIn", false)
                    apply()
                }
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
            builder.setNegativeButton("Cancel", null)
            builder.show()
        }
    }
}