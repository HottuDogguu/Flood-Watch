package com.example.floodwatch

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var emailInput: TextInputEditText
    private lateinit var passwordInput: TextInputEditText
    private lateinit var loginButton: MaterialButton
    private lateinit var signupText: TextView
    private lateinit var googleSignInButton: MaterialButton
    private lateinit var forgotPasswordText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Check if user is already logged in
        val prefs = getSharedPreferences("FloodWatchPrefs", MODE_PRIVATE)
        val isLoggedIn = prefs.getBoolean("isLoggedIn", false)

        if (isLoggedIn) {
            // User is already logged in, go to Home
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
            return
        }

        // Initialize views
        emailInput = findViewById(R.id.emailInput)
        passwordInput = findViewById(R.id.passwordInput)
        loginButton = findViewById(R.id.loginButton)
        signupText = findViewById(R.id.signupButton)
        googleSignInButton = findViewById(R.id.googleSignInButton)
        forgotPasswordText = findViewById(R.id.forgotPasswordText)

        // Login button click
        loginButton.setOnClickListener {
            val email = emailInput.text.toString()
            val password = passwordInput.text.toString()

            if (validateInput(email, password)) {
                // Store login state
                prefs.edit().apply {
                    putBoolean("isLoggedIn", true)
                    putString("userEmail", email)
                    apply()
                }

                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()

                // Navigate to Home
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }
        }

        // Signup text click
        signupText.setOnClickListener {
            val email = emailInput.text.toString()
            val password = passwordInput.text.toString()

            if (validateInput(email, password)) {
                Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show()

                // Store user data
                prefs.edit().apply {
                    putBoolean("isLoggedIn", true)
                    putString("userEmail", email)
                    apply()
                }

                // Navigate to Home
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }
        }

        // Google Sign-In button click
        googleSignInButton.setOnClickListener {
            Toast.makeText(this, "Google Sign-In coming soon!", Toast.LENGTH_SHORT).show()
            // TODO: Implement Google Sign-In
        }

        // Forgot Password text click
        forgotPasswordText.setOnClickListener {
            val email = emailInput.text.toString()

            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter your email first", Toast.LENGTH_SHORT).show()
                emailInput.requestFocus()
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_SHORT).show()
                emailInput.requestFocus()
            } else {
                Toast.makeText(this, "Password reset link sent to $email", Toast.LENGTH_SHORT).show()
                // TODO: Implement password reset functionality
            }
        }
    }

    private fun validateInput(email: String, password: String): Boolean {
        if (email.isEmpty()) {
            emailInput.error = "Email is required"
            emailInput.requestFocus()
            return false
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.error = "Invalid email format"
            emailInput.requestFocus()
            return false
        }

        if (password.isEmpty()) {
            passwordInput.error = "Password is required"
            passwordInput.requestFocus()
            return false
        }

        if (password.length < 6) {
            passwordInput.error = "Password must be at least 6 characters"
            passwordInput.requestFocus()
            return false
        }

        return true
    }
}